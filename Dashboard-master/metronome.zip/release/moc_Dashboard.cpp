/****************************************************************************
** Meta object code from reading C++ file 'Dashboard.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Dashboard.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Dashboard.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Dashboard_t {
    QByteArrayData data[27];
    char stringdata0[331];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Dashboard_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Dashboard_t qt_meta_stringdata_Dashboard = {
    {
QT_MOC_LITERAL(0, 0, 9), // "Dashboard"
QT_MOC_LITERAL(1, 10, 17), // "startAngleChanged"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 10), // "startAngle"
QT_MOC_LITERAL(4, 40, 16), // "spanAngleChanged"
QT_MOC_LITERAL(5, 57, 9), // "spanAngle"
QT_MOC_LITERAL(6, 67, 15), // "minValueChanged"
QT_MOC_LITERAL(7, 83, 8), // "minValue"
QT_MOC_LITERAL(8, 92, 15), // "maxValueChanged"
QT_MOC_LITERAL(9, 108, 8), // "maxValue"
QT_MOC_LITERAL(10, 117, 12), // "valueChanged"
QT_MOC_LITERAL(11, 130, 5), // "value"
QT_MOC_LITERAL(12, 136, 14), // "divisorChanged"
QT_MOC_LITERAL(13, 151, 7), // "divisor"
QT_MOC_LITERAL(14, 159, 16), // "precisionChanged"
QT_MOC_LITERAL(15, 176, 9), // "precision"
QT_MOC_LITERAL(16, 186, 19), // "divisorSplitChanged"
QT_MOC_LITERAL(17, 206, 12), // "divisorSplit"
QT_MOC_LITERAL(18, 219, 11), // "timeoutSlot"
QT_MOC_LITERAL(19, 231, 13), // "setStartAngle"
QT_MOC_LITERAL(20, 245, 12), // "setSpanAngle"
QT_MOC_LITERAL(21, 258, 11), // "setMinValue"
QT_MOC_LITERAL(22, 270, 11), // "setMaxValue"
QT_MOC_LITERAL(23, 282, 8), // "setValue"
QT_MOC_LITERAL(24, 291, 10), // "setDivisor"
QT_MOC_LITERAL(25, 302, 12), // "setPrecision"
QT_MOC_LITERAL(26, 315, 15) // "setDivisorSplit"

    },
    "Dashboard\0startAngleChanged\0\0startAngle\0"
    "spanAngleChanged\0spanAngle\0minValueChanged\0"
    "minValue\0maxValueChanged\0maxValue\0"
    "valueChanged\0value\0divisorChanged\0"
    "divisor\0precisionChanged\0precision\0"
    "divisorSplitChanged\0divisorSplit\0"
    "timeoutSlot\0setStartAngle\0setSpanAngle\0"
    "setMinValue\0setMaxValue\0setValue\0"
    "setDivisor\0setPrecision\0setDivisorSplit"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Dashboard[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       8,  148, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   99,    2, 0x06 /* Public */,
       4,    1,  102,    2, 0x06 /* Public */,
       6,    1,  105,    2, 0x06 /* Public */,
       8,    1,  108,    2, 0x06 /* Public */,
      10,    1,  111,    2, 0x06 /* Public */,
      12,    1,  114,    2, 0x06 /* Public */,
      14,    1,  117,    2, 0x06 /* Public */,
      16,    1,  120,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      18,    0,  123,    2, 0x0a /* Public */,
      19,    1,  124,    2, 0x0a /* Public */,
      20,    1,  127,    2, 0x0a /* Public */,
      21,    1,  130,    2, 0x0a /* Public */,
      22,    1,  133,    2, 0x0a /* Public */,
      23,    1,  136,    2, 0x0a /* Public */,
      24,    1,  139,    2, 0x0a /* Public */,
      25,    1,  142,    2, 0x0a /* Public */,
      26,    1,  145,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QReal,    3,
    QMetaType::Void, QMetaType::QReal,    5,
    QMetaType::Void, QMetaType::QReal,    7,
    QMetaType::Void, QMetaType::QReal,    9,
    QMetaType::Void, QMetaType::QReal,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Bool,   17,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QReal,    3,
    QMetaType::Void, QMetaType::QReal,    5,
    QMetaType::Void, QMetaType::QReal,    7,
    QMetaType::Void, QMetaType::QReal,    9,
    QMetaType::Void, QMetaType::QReal,   11,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Bool,   17,

 // properties: name, type, flags
       3, QMetaType::QReal, 0x00495103,
       5, QMetaType::QReal, 0x00495103,
       7, QMetaType::QReal, 0x00495103,
       9, QMetaType::QReal, 0x00495103,
      11, QMetaType::QReal, 0x00495103,
      13, QMetaType::Int, 0x00495103,
      15, QMetaType::Int, 0x00495103,
      17, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,

       0        // eod
};

void Dashboard::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Dashboard *_t = static_cast<Dashboard *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->startAngleChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 1: _t->spanAngleChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 2: _t->minValueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 3: _t->maxValueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 4: _t->valueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 5: _t->divisorChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->precisionChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->divisorSplitChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->timeoutSlot(); break;
        case 9: _t->setStartAngle((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 10: _t->setSpanAngle((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 11: _t->setMinValue((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 12: _t->setMaxValue((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 13: _t->setValue((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 14: _t->setDivisor((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->setPrecision((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->setDivisorSplit((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Dashboard::*_t)(qreal );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::startAngleChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Dashboard::*_t)(qreal );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::spanAngleChanged)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Dashboard::*_t)(qreal );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::minValueChanged)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Dashboard::*_t)(qreal );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::maxValueChanged)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (Dashboard::*_t)(qreal );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::valueChanged)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (Dashboard::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::divisorChanged)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (Dashboard::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::precisionChanged)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (Dashboard::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Dashboard::divisorSplitChanged)) {
                *result = 7;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        Dashboard *_t = static_cast<Dashboard *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< qreal*>(_v) = _t->startAngle(); break;
        case 1: *reinterpret_cast< qreal*>(_v) = _t->spanAngle(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->minValue(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->maxValue(); break;
        case 4: *reinterpret_cast< qreal*>(_v) = _t->value(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->divisor(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->precision(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->divisorSplit(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        Dashboard *_t = static_cast<Dashboard *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setStartAngle(*reinterpret_cast< qreal*>(_v)); break;
        case 1: _t->setSpanAngle(*reinterpret_cast< qreal*>(_v)); break;
        case 2: _t->setMinValue(*reinterpret_cast< qreal*>(_v)); break;
        case 3: _t->setMaxValue(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setValue(*reinterpret_cast< qreal*>(_v)); break;
        case 5: _t->setDivisor(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setPrecision(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setDivisorSplit(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject Dashboard::staticMetaObject = {
    { &QQuickPaintedItem::staticMetaObject, qt_meta_stringdata_Dashboard.data,
      qt_meta_data_Dashboard,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Dashboard::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dashboard::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Dashboard.stringdata0))
        return static_cast<void*>(const_cast< Dashboard*>(this));
    return QQuickPaintedItem::qt_metacast(_clname);
}

int Dashboard::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickPaintedItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Dashboard::startAngleChanged(qreal _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Dashboard::spanAngleChanged(qreal _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Dashboard::minValueChanged(qreal _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Dashboard::maxValueChanged(qreal _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Dashboard::valueChanged(qreal _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Dashboard::divisorChanged(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Dashboard::precisionChanged(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void Dashboard::divisorSplitChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
